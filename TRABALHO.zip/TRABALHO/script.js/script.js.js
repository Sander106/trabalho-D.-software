function mostrarMensagem() {
  document.getElementById("mensagem").innerText = "ESTE SOU EU, あなたは誰ですか?";
}
